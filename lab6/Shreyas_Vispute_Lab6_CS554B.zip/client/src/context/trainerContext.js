import React from "react";

const TrainerContext = React.createContext();
export default TrainerContext;
